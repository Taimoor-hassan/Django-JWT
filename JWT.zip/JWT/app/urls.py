from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from app import views

urlpatterns = [
    path('', csrf_exempt(views.UserView.as_view())),
    path('register/', csrf_exempt(views.UserView.as_view())),
    path('login/', csrf_exempt(views.LoginView.as_view())),
    path('logout/', csrf_exempt(views.DeleteSessionView.as_view())),
    path('user/', csrf_exempt(views.UserDetailView.as_view()))
]
