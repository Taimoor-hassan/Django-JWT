import json
from datetime import datetime
from json import dumps
from django.shortcuts import render
from rest_framework import status
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from .serializers import UserSerializer
from rest_framework.views import APIView
from .models import UserModel
import jwt, datetime


class UserView(APIView):

    # GET ALL THE USERS

    def get(self, request):
        data = UserModel.objects.all()
        serializer = UserSerializer(data, many=True)
        return Response(serializer.data)

    # CREATE NEW USERS

    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):

    # LOGIN USING TOKENS
    def post(self, request):
        email = request.data['email']
        password = request.data['password']

        user = UserModel.objects.filter(email=email).first()
        if user is None:
            raise AuthenticationFailed('User dosent exist')

        if not user.check_password(password):
            raise AuthenticationFailed('Incorrect password')

        payload = {
            'id': user.id,
            'email': user.email
            # 'exp': datetime.datetime.utcnow()+datetime.timedelta(minutes=60),
            # 'tat': datetime.datetime.utcnow()
            }
        jwt_token = {'token': jwt.encode(payload, "SECRET_KEY")}
        token = jwt.encode(payload, 'secret', algorithm='HS256')

        response = Response()
        response.set_cookie('jwt', token, httponly=True)
        response.data = {
            'message': 'Login Successful',
            'jwt-token': token
            # 'token': json.dumps(token)
        }
        return response


class UserDetailView(APIView):

    # GET DETAIL OF USER WHEN HE IS LOGGED IN THE SESSION
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Failed authentication')
        try:
            payload = jwt.decode(token, 'secret', algorithms='HS256')
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Failed authentication')

        user = UserModel.objects.filter(email=payload['email']).first()
        serailizer = UserSerializer(user)

        return Response(serailizer.data)


class DeleteSessionView(APIView):
    def post(self, request):
        response = Response()
        response.delete_cookie('jwt')
        response.data = {
            'message': 'Logged Out'
        }
        return response
